import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

plt.figure(figsize=(15,15))
n=4
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(331)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)


n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(332)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)

n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(333)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)
n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(334)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)

n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(335)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)

n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(336)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)

n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(337)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)

n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(338)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)

n=n+1
a1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tlx.csv", dtype='float32').values[n*201:(n+1)*201]
b1=pd.read_csv(r"C:\Users\Administrator.DESKTOP-AU6E7RR\Desktop\result\tly.csv", dtype='float32').values[n*201:(n+1)*201]
c1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,0]
d1=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv", dtype='float32').values[n*201:(n+1)*201,1]
plt.subplot(339)


plt.plot(c1,d1,'*',label='reference',color="darkorange")
plt.plot(a1,b1,'.',label='tracking trajectory')
plt.legend(loc='upper right')
plt.tick_params(labelsize=10)
# plt.xlabel('x',fontdict={"family":"Times New Roman","size":15})
plt.ylabel('y',fontdict={"family":"Times New Roman","size":15})
plt.title('x',fontdict={"family":"Times New Roman","size":15},x=0.5,y=-0.2)

plt.savefig('./fangzhen.png', bbox_inches = 'tight',)
plt.show()