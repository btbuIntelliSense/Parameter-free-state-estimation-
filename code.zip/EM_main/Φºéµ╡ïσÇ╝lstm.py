import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pykalman import KalmanFilter
import lstm
import transformer
import time
import torch
import os
from sklearn.metrics import mean_squared_error,mean_absolute_error
import math
from sklearn.preprocessing import StandardScaler,MinMaxScaler
os.environ['KMP_DUPLICATE_LIB_OK']='True'
random_state = np.random.RandomState(0)
torch.manual_seed(0)
T = 0.01
step = 200


A= np.array([[1,T, 0.5*T*T],
 [ 0, 1,T],
 [ 0, 0, 1]])
B= [0, 0, 0]
C= [1,0,0]
D= [0]
Q= 0.01*np.eye(3)
R= 0.005*np.eye(1)
m0= [ 0,0,0.1]
P0= 0.1*np.eye(3)

kft = KalmanFilter(
    A,C,Q,R,B,D,m0,P0,
    random_state=random_state
)# model should be

# state, observation = kft.sample(
#     n_timesteps=step,
#     initial_state=m0
#     )
# provide data
#filtered_state_estimatet, f_covt = kft.filter(observation)
#smoothed_state_estimatet, s_covt = kft.smooth(observation)

state=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动真实.csv").values
observation=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\手动噪声.csv").values
state=state[:,1]
observation=observation[:,1]
'''
Step 2: Initialize our model
'''

# specify parameters
transition_matrix = A
transition_offset = B
observation_matrix = C
observation_offset = D
transition_covariance = 0.02*np.eye(3)
observation_covariance = np.eye(1)
initial_state_mean =[0,0,1]

initial_state_covariance = 5*np.eye(3)

# sample from model

kf = KalmanFilter(
    transition_matrix, observation_matrix, transition_covariance,
    observation_covariance, transition_offset, observation_offset,initial_state_mean,initial_state_covariance,
    random_state=random_state,
    em_vars=[
      #'transition_matrices', 'observation_matrices',
      'transition_covariance','observation_covariance',
      #'transition_offsets', 'observation_offsets',
      'initial_state_mean', 'initial_state_covariance'
      ])
def compute_tr(a):
    size = a.shape[0]
    return (np.trace(a)/size)*np.eye(size)
data=pd.read_csv(r"D:\研究生\研1\论文\轨迹跟踪论文\手动GPS数据\CA.csv").values
data=data[0:200,1]
data=data.reshape(-1,1)
kfem = kf.em(X=data, n_iter=10)
Qem = compute_tr(kfem.transition_covariance)
Rem = compute_tr(kfem.observation_covariance)
P0em = compute_tr(kfem.initial_state_covariance)
m0em = [0, 0, np.abs(kfem.initial_state_mean[2])]
print('Q=', Qem)
print('R=', Rem)
print('m0=', m0em)
print('P0=', P0em)
kfem = KalmanFilter(
    A, C, Qem, Rem, B, D, m0em, P0em,
    random_state=random_state
)
filtered_state_estimates, f_cov = kfem.filter(observation)
RMSE = math.sqrt(mean_squared_error(filtered_state_estimates[:,0].reshape(-1, 1), state.reshape(-1, 1)))
print(RMSE)